// main.ts — Orchestrator.

import { initDetector, detectFaces, type FaceBox } from "./detector";
import { frameToAscii, drawAsciiToCanvas, type RampName } from "./ascii";

const $ = <T extends HTMLElement>(id: string) => {
  const el = document.getElementById(id);
  if (!el) throw new Error(`Missing #${id}`);
  return el as T;
};

const video = $<HTMLVideoElement>("video");
const sampler = $<HTMLCanvasElement>("sampler");
const asciiText = $<HTMLPreElement>("ascii-text");
const asciiCanvas = $<HTMLCanvasElement>("ascii-canvas");
const placeholder = $<HTMLDivElement>("placeholder");
const startBtn = $<HTMLButtonElement>("start");
const statusEl = $<HTMLSpanElement>("status");
const fpsEl = $<HTMLSpanElement>("fps");
const msgEl = $<HTMLSpanElement>("msg");
const modeSel = $<HTMLSelectElement>("mode");
const densityInput = $<HTMLInputElement>("density");
const densityVal = $<HTMLSpanElement>("density-val");
const rampSel = $<HTMLSelectElement>("ramp");
const invertCb = $<HTMLInputElement>("invert");

interface State {
  mode: "dom" | "canvas";
  cols: number;
  ramp: RampName;
  invert: boolean;
  // Smoothed face box — avoids jitter between detections.
  smoothed: FaceBox | null;
  lastDetectAt: number;
  lastFaceSeenAt: number;
  detectionIntervalMs: number;
  /** Keep showing the last face for this long after a miss, to avoid flicker. */
  missGraceMs: number;
  frameCount: number;
  lastFpsAt: number;
  running: boolean;
  /** Track last fit params so we only reflow the <pre> when they change. */
  lastFit: { cols: number; rows: number; w: number; h: number } | null;
}

const state: State = {
  mode: "dom",
  cols: 90,
  ramp: "standard",
  invert: false,
  smoothed: null,
  lastDetectAt: 0,
  lastFaceSeenAt: 0,
  // Detection at ~30Hz max; render every animation frame.
  detectionIntervalMs: 1000 / 30,
  missGraceMs: 400,
  frameCount: 0,
  lastFpsAt: performance.now(),
  running: false,
  lastFit: null,
};

function setStatus(text: string, kind: "init" | "ok" | "warn" | "err" = "init") {
  statusEl.textContent = text;
  statusEl.dataset.state = kind;
}

function setMsg(text: string) {
  msgEl.textContent = text;
}

// --- UI bindings ---

modeSel.addEventListener("change", () => {
  state.mode = modeSel.value as "dom" | "canvas";
  asciiText.classList.toggle("hidden", state.mode !== "dom");
  asciiCanvas.classList.toggle("hidden", state.mode !== "canvas");
});

densityInput.addEventListener("input", () => {
  state.cols = Number(densityInput.value);
  densityVal.textContent = String(state.cols);
});
densityVal.textContent = densityInput.value;

rampSel.addEventListener("change", () => {
  state.ramp = rampSel.value as RampName;
});

invertCb.addEventListener("change", () => {
  state.invert = invertCb.checked;
});

startBtn.addEventListener("click", boot);

// --- Boot sequence ---

async function boot() {
  startBtn.disabled = true;
  setStatus("REQUEST CAM", "init");

  try {
    const stream = await navigator.mediaDevices.getUserMedia({
      video: { facingMode: "user", width: 1280, height: 720 },
      audio: false,
    });
    video.srcObject = stream;
    await new Promise<void>((resolve, reject) => {
      video.onloadedmetadata = () => resolve();
      video.onerror = () => reject(new Error("video failed to load"));
    });
    await video.play();
  } catch (err) {
    console.error(err);
    setStatus("CAM DENIED", "err");
    setMsg(err instanceof Error ? err.message : String(err));
    startBtn.disabled = false;
    return;
  }

  setStatus("LOAD MODEL", "init");
  try {
    await initDetector();
  } catch (err) {
    console.error(err);
    setStatus("MODEL FAIL", "err");
    setMsg(err instanceof Error ? err.message : String(err));
    startBtn.disabled = false;
    return;
  }

  placeholder.classList.add("hidden");
  setStatus("ONLINE", "ok");
  state.running = true;
  requestAnimationFrame(loop);
}

// --- Smoothing ---
// Exponential moving average on the face box to kill jitter.
const SMOOTH_ALPHA = 0.35; // higher = more responsive, lower = smoother

function smooth(prev: FaceBox | null, next: FaceBox): FaceBox {
  if (!prev) return next;
  const a = SMOOTH_ALPHA;
  return {
    x: prev.x * (1 - a) + next.x * a,
    y: prev.y * (1 - a) + next.y * a,
    w: prev.w * (1 - a) + next.w * a,
    h: prev.h * (1 - a) + next.h * a,
    score: next.score,
  };
}

// --- Render loop ---

function loop(now: number) {
  if (!state.running) return;

  // Detection at throttled rate
  if (now - state.lastDetectAt >= state.detectionIntervalMs) {
    state.lastDetectAt = now;
    try {
      const faces = detectFaces(video, now);
      if (faces.length > 0) {
        // Pick the largest (closest) face.
        const biggest = faces.reduce((a, b) =>
          a.w * a.h >= b.w * b.h ? a : b,
        );
        state.smoothed = smooth(state.smoothed, biggest);
        state.lastFaceSeenAt = now;
        setStatus(`FACE ${(biggest.score * 100).toFixed(0)}%`, "ok");
      } else {
        // Grace period: keep last smoothed box until missGraceMs elapses.
        if (now - state.lastFaceSeenAt > state.missGraceMs) {
          state.smoothed = null;
          setStatus("SCAN", "warn");
        }
      }
    } catch (err) {
      console.error("detect error", err);
    }
  }

  // Render
  if (state.smoothed) {
    const frame = frameToAscii({
      video,
      sampler,
      face: state.smoothed,
      cols: state.cols,
      ramp: state.ramp,
      invert: state.invert,
      pad: 0.18,
    });
    if (frame) {
      if (state.mode === "dom") {
        // Fit the <pre> font-size so the text fills the stage.
        fitDomText(frame.cols, frame.rows);
        asciiText.textContent = frame.text;
      } else {
        drawAsciiToCanvas(asciiCanvas, frame, "#b8ffb8");
      }
    }
  } else {
    if (state.mode === "dom") asciiText.textContent = "";
    else {
      const ctx = asciiCanvas.getContext("2d");
      if (ctx) {
        ctx.fillStyle = "#050807";
        ctx.fillRect(0, 0, asciiCanvas.width, asciiCanvas.height);
      }
    }
  }

  // FPS counter
  state.frameCount++;
  if (now - state.lastFpsAt >= 500) {
    const fps = (state.frameCount * 1000) / (now - state.lastFpsAt);
    fpsEl.textContent = `${fps.toFixed(0)} fps`;
    state.frameCount = 0;
    state.lastFpsAt = now;
  }

  requestAnimationFrame(loop);
}

// Dynamically size the DOM <pre> so ASCII fills the stage cleanly.
// Only recomputes when inputs change — avoids reflow on every frame.
function fitDomText(cols: number, rows: number) {
  const parent = asciiText.parentElement!;
  const W = parent.clientWidth;
  const H = parent.clientHeight;
  const fit = state.lastFit;
  if (fit && fit.cols === cols && fit.rows === rows && fit.w === W && fit.h === H) {
    return;
  }
  // Monospace char box ≈ 0.6 width × 1.0 height of font-size (with line-height: 1).
  const sizeByW = W / (cols * 0.6);
  const sizeByH = H / rows;
  const fontSize = Math.max(2, Math.floor(Math.min(sizeByW, sizeByH)));
  asciiText.style.fontSize = `${fontSize}px`;
  state.lastFit = { cols, rows, w: W, h: H };
}

// Invalidate the cached fit on resize so the text reflows.
window.addEventListener("resize", () => {
  state.lastFit = null;
});

// Tidy up on tab close.
window.addEventListener("beforeunload", () => {
  state.running = false;
  const s = video.srcObject as MediaStream | null;
  s?.getTracks().forEach((t) => t.stop());
});
