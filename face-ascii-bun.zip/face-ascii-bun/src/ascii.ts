// ascii.ts — Pixel grid → ASCII art.
// Handles char aspect ratio (monospace chars are ~2x tall as wide).

export type RampName = "standard" | "dense" | "blocks" | "binary";

const RAMPS: Record<RampName, string> = {
  // Light → dark. Index 0 = brightest pixel rendered as space.
  standard: " .:-=+*#%@",
  dense: " .'`^\",:;Il!i><~+_-?][}{1)(|/tfjrxnuvczXYUJCLQ0OZmwqpdbkhao*#MW&8%B@$",
  blocks: " ░▒▓█",
  binary: " #",
};

export interface RenderOpts {
  /** Source video element (mirrored display recommended via CSS, not done here). */
  video: HTMLVideoElement;
  /** Off-screen canvas used to sample the face region. */
  sampler: HTMLCanvasElement;
  /** Face bounding box in *video* pixel coords, or null for no face. */
  face: { x: number; y: number; w: number; h: number } | null;
  /** Character columns across the face. */
  cols: number;
  ramp: RampName;
  invert: boolean;
  /** Padding factor — expands box around face. 0.15 = 15% extra on each side. */
  pad: number;
}

export interface AsciiFrame {
  text: string;
  cols: number;
  rows: number;
}

/**
 * Sample the face region from the video and produce an ASCII string.
 * The character aspect ratio is corrected (monospace chars are ~2x tall as wide)
 * so the face isn't vertically stretched.
 */
export function frameToAscii(opts: RenderOpts): AsciiFrame | null {
  const { video, sampler, face, cols, ramp, invert, pad } = opts;
  if (!face || video.videoWidth === 0) return null;

  // Expand face box by `pad` on each side; clamp to video bounds.
  const vw = video.videoWidth;
  const vh = video.videoHeight;
  const padX = face.w * pad;
  const padY = face.h * pad;
  const sx = Math.max(0, Math.floor(face.x - padX));
  const sy = Math.max(0, Math.floor(face.y - padY));
  const sw = Math.min(vw - sx, Math.ceil(face.w + 2 * padX));
  const sh = Math.min(vh - sy, Math.ceil(face.h + 2 * padY));
  if (sw < 8 || sh < 8) return null;

  // Char aspect: empirically ~0.5 for most monospace fonts.
  const CHAR_ASPECT = 0.5;
  const rows = Math.max(1, Math.floor((cols * (sh / sw)) * CHAR_ASPECT));

  // Render the cropped face onto the sampler canvas at exactly cols×rows.
  // The browser does the resampling for us (much faster than per-pixel JS).
  sampler.width = cols;
  sampler.height = rows;
  const ctx = sampler.getContext("2d", { willReadFrequently: true });
  if (!ctx) return null;

  // Mirror horizontally so the user sees a selfie view.
  ctx.save();
  ctx.translate(cols, 0);
  ctx.scale(-1, 1);
  ctx.drawImage(video, sx, sy, sw, sh, 0, 0, cols, rows);
  ctx.restore();

  const { data } = ctx.getImageData(0, 0, cols, rows);
  const glyphs = RAMPS[ramp];
  const last = glyphs.length - 1;

  let out = "";
  let i = 0;
  for (let y = 0; y < rows; y++) {
    for (let x = 0; x < cols; x++) {
      const r = data[i];
      const g = data[i + 1];
      const b = data[i + 2];
      // Rec. 709 luminance.
      let lum = (0.2126 * r + 0.7152 * g + 0.0722 * b) / 255;
      if (invert) lum = 1 - lum;
      const idx = Math.round(lum * last);
      out += glyphs[idx];
      i += 4;
    }
    out += "\n";
  }
  return { text: out, cols, rows };
}

/**
 * Render ASCII to a canvas (smoother / animated style).
 * Sizes the canvas to the parent container and draws glyphs at computed cell size.
 */
export function drawAsciiToCanvas(
  canvas: HTMLCanvasElement,
  frame: AsciiFrame,
  color: string,
): void {
  const dpr = window.devicePixelRatio || 1;
  const parent = canvas.parentElement!;
  const W = parent.clientWidth;
  const H = parent.clientHeight;

  // Pick cell size so cols×rows fits within W×H while respecting char aspect.
  // Char box: cellW × cellH where cellH ≈ cellW * 2 (the inverse of our 0.5 sampling).
  const maxCellW_byWidth = W / frame.cols;
  const maxCellW_byHeight = H / frame.rows / 2; // because cellH = 2*cellW
  const cellW = Math.floor(Math.min(maxCellW_byWidth, maxCellW_byHeight));
  const cellH = cellW * 2;
  if (cellW < 2) return;

  const drawW = cellW * frame.cols;
  const drawH = cellH * frame.rows;

  canvas.width = drawW * dpr;
  canvas.height = drawH * dpr;
  canvas.style.width = `${drawW}px`;
  canvas.style.height = `${drawH}px`;

  const ctx = canvas.getContext("2d");
  if (!ctx) return;
  ctx.scale(dpr, dpr);
  ctx.fillStyle = "#050807";
  ctx.fillRect(0, 0, drawW, drawH);

  ctx.fillStyle = color;
  ctx.font = `700 ${cellH}px "JetBrains Mono", monospace`;
  ctx.textBaseline = "top";
  ctx.shadowColor = color;
  ctx.shadowBlur = 4;

  const lines = frame.text.split("\n");
  for (let y = 0; y < frame.rows; y++) {
    const line = lines[y] ?? "";
    for (let x = 0; x < frame.cols; x++) {
      const ch = line[x];
      if (!ch || ch === " ") continue;
      ctx.fillText(ch, x * cellW, y * cellH - cellH * 0.15);
    }
  }
}
